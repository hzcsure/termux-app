#!/data/data/com.termux/files/usr/bin/bash
# tv-setup.sh — fully offline deploy from /data/local/tmp/tv/
# Run this from Termux. No internet needed for package installation.
set -e

PKG="/data/local/tmp/tv"
HOME="/data/data/com.termux/files/home"

[ ! -d "$PKG" ] && { echo "ERROR: $PKG not found. Run adb push first."; exit 1; }

echo "=== tv-setup offline deploy ==="

# ─── 1. offline package install ───
echo "[1] installing packages from $PKG/debs/ ..."
if [ -d "$PKG/debs" ] && ls $PKG/debs/*.deb >/dev/null 2>&1; then
    set +e
    dpkg -i --force-all $PKG/debs/*.deb
    dpkg --configure -a
    set -e
    echo "  packages installed"
else
    echo "  WARNING: $PKG/debs/ not found, skipping pkg install"
fi

# ─── 2. directories ───
echo "[2] creating dirs..."
mkdir -p $HOME/.local/bin $HOME/.sing-box $HOME/log

# ─── 3. deploy bin ───
echo "[3] deploying scripts..."
cp $PKG/bin/tvproxy       $HOME/.local/bin/
cp $PKG/bin/tvproxy-sub   $HOME/.local/bin/
cp $PKG/bin/tvproxy-url   $HOME/.local/bin/
cp $PKG/bin/logrotate     $HOME/.local/bin/
cp $PKG/bin/xor-enc       $HOME/.local/bin/
chmod 755 $HOME/.local/bin/tvproxy $HOME/.local/bin/tvproxy-sub \
          $HOME/.local/bin/tvproxy-url $HOME/.local/bin/logrotate $HOME/.local/bin/xor-enc

# ─── 4. deploy config ───
echo "[4] deploying config..."
cp $PKG/tvproxy.conf  $HOME/.local/bin/
cp $PKG/ua.type       $HOME/.local/bin/
cp $PKG/bashrc        $HOME/.bashrc
cp $PKG/sub_urls      $HOME/.sing-box/
cp $PKG/crontab       $HOME/.sing-box/crontab.bak

# ─── 5. crontab + crond ───
echo "[5] setting up crontab..."
crontab $HOME/.sing-box/crontab.bak 2>/dev/null || true
pkill crond 2>/dev/null || true
crond
echo "  jobs: $(crontab -l 2>/dev/null | grep -c tvproxy)"

# ─── 6. tvproxy update ───
echo "[6] fetching subscriptions..."
export PATH="$HOME/.local/bin:$PATH"
tvproxy update 2>&1 | tail -5

echo ""
echo "=== setup complete ==="
echo "  tvproxy list  — see all nodes"
echo "  tvproxy status — check current node"
