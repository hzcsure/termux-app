#!/data/data/com.termux/files/usr/bin/bash
# tv-setup.sh — offline package install from ~/debs
set -e
HOME="/data/data/com.termux/files/home"
echo "=== tv-setup ==="

# 1. install offline debs
echo "[1] installing packages from ~/debs ..."
if ls "$HOME/debs"/*.deb >/dev/null 2>&1; then
    dpkg -i --force-all "$HOME/debs"/*.deb
    dpkg --configure -a
    rm -rf "$HOME/debs"
    echo "  packages installed"
else
    echo "  no debs found, skipping"
fi

# 2. fix permissions
echo "[2] fixing permissions ..."
chmod 755 "$HOME/.local/bin/tvproxy" "$HOME/.local/bin/tvproxy-sub" \
          "$HOME/.local/bin/tvproxy-url" "$HOME/.local/bin/logrotate" \
          "$HOME/.local/bin/xor-enc" 2>/dev/null || true

# 3. create log dir
echo "[3] creating directories ..."
mkdir -p "$HOME/log"

echo "=== setup complete ==="
