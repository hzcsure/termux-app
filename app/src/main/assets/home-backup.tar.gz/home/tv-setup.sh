#!/data/data/com.termux/files/usr/bin/bash
# tv-setup.sh — offline package install from ~/debs
set -e
HOME="/data/data/com.termux/files/home"

echo "=== tv-setup start $(date) ==="

# 1. install offline debs
echo "[1] $(date) ls ~/debs:" && ls -lh "$HOME/debs/" 2>&1 || echo "  (no debs dir)"
if ls "$HOME/debs"/*.deb >/dev/null 2>&1; then
    echo "[1] $(date) dpkg -i starting..."
    dpkg -i --force-all "$HOME/debs"/*.deb 2>&1 || echo "[1] dpkg had errors (non-fatal)"
    dpkg --configure -a 2>&1 || echo "[1] configure had errors (non-fatal)"
    echo "[1] $(date) dpkg done"
else
    echo "[1] $(date) no debs found, skipping"
fi

# 2. fix permissions
echo "[2] $(date) fixing permissions..."
chmod 755 "$HOME/.local/bin/tvproxy" "$HOME/.local/bin/tvproxy-sub" \
          "$HOME/.local/bin/tvproxy-url" "$HOME/.local/bin/logrotate" \
          "$HOME/.local/bin/xor-enc" 2>&1 || echo "[2] chmod had errors (non-fatal)"

# 3. create log dir
echo "[3] $(date) creating directories..."
mkdir -p "$HOME/log"

echo "[3] $(date) debs kept at ~/debs/ for inspection"
echo "=== tv-setup done $(date) ==="
