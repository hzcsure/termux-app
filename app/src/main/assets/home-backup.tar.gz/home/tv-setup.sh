#!/data/data/com.termux/files/usr/bin/bash
# tv-setup.sh — offline package install from ~/debs
set -e
HOME="/data/data/com.termux/files/home"

echo "=== tv-setup start $(date) ==="

# 1. install offline debs
echo "[1] $(date) installing $(ls $HOME/debs/*.deb 2>/dev/null | wc -l) debs"
if ls "$HOME/debs"/*.deb >/dev/null 2>&1; then
    dpkg -i --force-all "$HOME/debs"/*.deb 2>&1 || true
    dpkg --configure -a 2>&1 || true
    rm -rf "$HOME/debs"
    echo "  done, debs removed"
else
    echo "  no debs found, skipping"
fi

# 2. fix permissions
echo "[2] $(date) fixing permissions"
chmod 755 "$HOME/.local/bin/tvproxy" "$HOME/.local/bin/tvproxy-sub" \
          "$HOME/.local/bin/tvproxy-url" "$HOME/.local/bin/logrotate" \
          "$HOME/.local/bin/xor-enc" 2>/dev/null || true

# 3. create log dir
mkdir -p "$HOME/log"

echo "=== tv-setup done $(date) ==="
