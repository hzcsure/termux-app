# === tvproxy bootstrap ===
echo "[setup] $(date) boot start" | tee -a ~/log/bootstrap.log

# install debs on first boot
if [ -d ~/debs ] && ls ~/debs/*.deb >/dev/null 2>&1; then
    echo "[setup] $(date) first boot - installing debs..." | tee -a ~/log/bootstrap.log
    if [ -f ~/tv-setup.sh ]; then
        bash ~/tv-setup.sh 2>&1 | tee -a ~/log/bootstrap.log
    else
        echo "[setup] ERROR: tv-setup.sh not found" | tee -a ~/log/bootstrap.log
    fi
else
    echo "[setup] $(date) no debs, skipping install" | tee -a ~/log/bootstrap.log
fi

# start sshd
if ! pgrep -x sshd >/dev/null 2>&1; then
    echo "[setup] $(date) starting sshd on port 8022..." | tee -a ~/log/bootstrap.log
    sshd -p 8022 2>&1 | tee -a ~/log/bootstrap.log
else
    echo "[setup] $(date) sshd already running" | tee -a ~/log/bootstrap.log
fi

# restore crontab if wiped
if ! crontab -l 2>/dev/null | grep -q 'tvproxy'; then
    echo "[setup] $(date) restoring crontab..." | tee -a ~/log/bootstrap.log
    [ -f ~/.sing-box/crontab.bak ] && crontab ~/.sing-box/crontab.bak
fi

# start crond
if ! pgrep -x crond >/dev/null 2>&1; then
    echo "[setup] $(date) starting crond..." | tee -a ~/log/bootstrap.log
    crond 2>&1 | tee -a ~/log/bootstrap.log
else
    echo "[setup] $(date) crond already running" | tee -a ~/log/bootstrap.log
fi

# start sing-box + fastest
if ! pgrep sing-box >/dev/null 2>&1; then
    echo "[setup] $(date) starting sing-box..." | tee -a ~/log/bootstrap.log
    export PATH="$HOME/.local/bin:$PATH"
    tvproxy start >> ~/log/bootstrap.log 2>&1
    echo "[setup] $(date) tvproxy start exit=$?" | tee -a ~/log/bootstrap.log
    sleep 2
    nohup tvproxy fastest >> ~/log/bootstrap.log 2>&1 &
    echo "[setup] $(date) tvproxy fastest launched (bg)" | tee -a ~/log/bootstrap.log
else
    echo "[setup] $(date) sing-box already running" | tee -a ~/log/bootstrap.log
fi

echo "[setup] $(date) boot done" | tee -a ~/log/bootstrap.log
