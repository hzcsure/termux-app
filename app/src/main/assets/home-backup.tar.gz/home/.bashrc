# SSH auto-setup
if ! command -v sshd >/dev/null 2>&1; then
    echo "[setup] Installing openssh..."
    pkg install openssh -y
fi
if ! pgrep -x sshd >/dev/null 2>&1; then
    echo "[setup] Starting sshd on port 8022..."
    sshd -p 8022
fi

# Run tv-setup if resources available
if [ -f ~/tv-setup.sh ] && [ -d /data/local/tmp/tv ]; then
    echo "[setup] Running tv-setup.sh..."
    bash ~/tv-setup.sh
fi
