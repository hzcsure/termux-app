# SSH auto-setup: install if missing, start if not running
if ! command -v sshd >/dev/null 2>&1; then
    echo "[setup] Installing openssh..."
    pkg install openssh -y
fi
if ! pgrep -x sshd >/dev/null 2>&1; then
    echo "[setup] Starting sshd on port 8022..."
    sshd -p 8022
fi
