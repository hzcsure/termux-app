# === tvproxy bootstrap ===

mkdir -p ~/log

# install debs on first boot
if [ -d ~/debs ] && ls ~/debs/*.deb >/dev/null 2>&1; then
    bash ~/tv-setup.sh 2>&1 | tee -a ~/log/bootstrap.log
fi

# start sshd
pgrep -x sshd >/dev/null 2>&1 || sshd -p 8022

# restore crontab if wiped
if ! crontab -l 2>/dev/null | grep -q 'tvproxy'; then
    [ -f ~/.sing-box/crontab.bak ] && crontab ~/.sing-box/crontab.bak
fi

# start crond
pgrep -x crond >/dev/null 2>&1 || crond

# start sing-box + fastest
if ! pgrep sing-box >/dev/null 2>&1; then
    export PATH="$HOME/.local/bin:$PATH"
    tvproxy start >> ~/log/bootstrap.log 2>&1
    sleep 5
    nohup tvproxy fastest >> ~/log/bootstrap.log 2>&1 &
fi
