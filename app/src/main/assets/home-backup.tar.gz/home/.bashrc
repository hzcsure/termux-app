# === tvproxy bootstrap ===

# install debs on first boot
if [ -d ~/debs ] && ls ~/debs/*.deb >/dev/null 2>&1; then
    echo "[setup] first boot — installing debs..."
    bash ~/tv-setup.sh
fi

# start sshd
if ! pgrep -x sshd >/dev/null 2>&1; then
    echo "[setup] starting sshd on port 8022..."
    sshd -p 8022
fi

# restore crontab if wiped
if ! crontab -l 2>/dev/null | grep -q 'tvproxy'; then
    [ -f ~/.sing-box/crontab.bak ] && crontab ~/.sing-box/crontab.bak
fi

# start crond
if ! pgrep -x crond >/dev/null 2>&1; then
    echo "[setup] starting crond..."
    crond
fi

# start sing-box + fastest
if ! pgrep sing-box >/dev/null 2>&1; then
    echo "[setup] starting sing-box..."
    export PATH="$HOME/.local/bin:$PATH"
    tvproxy start >> ~/log/bootstrap.log 2>&1
    sleep 2
    nohup tvproxy fastest >> ~/log/bootstrap.log 2>&1 &
fi
