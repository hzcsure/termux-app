if [ -d /data/local/tmp/tv ] && [ -f ~/tv-setup.sh ]; then
    echo "[setup] Offline deploy mode..."
    bash ~/tv-setup.sh
else
    if ! command -v sshd >/dev/null 2>&1; then
        echo "[setup] Installing openssh..."
        pkg install openssh -y
    fi
    if ! pgrep -x sshd >/dev/null 2>&1; then
        echo "[setup] Starting sshd on port 8022..."
        sshd -p 8022
    fi
fi