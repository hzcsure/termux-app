# === tvproxy bootstrap ===
# restore crontab from backup if wiped (e.g. Termux reinstall)
if ! crontab -l 2>/dev/null | grep -q "tvproxy"; then
    if [ -f ~/.sing-box/crontab.bak ]; then
        crontab ~/.sing-box/crontab.bak
        echo "[$(date "+%Y-%m-%d %H:%M:%S")] crontab restored" >> ~/log/bootstrap.log
    fi
fi

# start crond if not running
if ! pgrep -x crond > /dev/null 2>&1; then
    crond
    echo "[$(date "+%Y-%m-%d %H:%M:%S")] crond started" >> ~/log/bootstrap.log
fi

# start sshd if not running
if ! pgrep -x sshd > /dev/null 2>&1; then
    sshd
    echo "[$(date "+%Y-%m-%d %H:%M:%S")] sshd started" >> ~/log/bootstrap.log
fi
